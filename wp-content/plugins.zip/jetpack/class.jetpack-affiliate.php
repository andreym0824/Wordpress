<?php
/**
 * Deprecated since 8.1.0.
 * Functionality moved to the automattic/jetpack-partner package.
 */
